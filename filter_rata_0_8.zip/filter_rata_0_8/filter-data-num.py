import json
import os
import numpy as np
import matplotlib.pyplot as plt

def extract_band_values(file_path):
    """
    提取JSON文件中所有对象的Band值并存储到numpy数组中

    Args:
        file_path (str): JSON文件的路径

    Returns:
        tuple: (numpy数组, 对象数量)，如果出错则返回(None, -1)
    """
    try:
        # 检查文件是否存在
        if not os.path.exists(file_path):
            print(f"错误：文件 '{file_path}' 不存在")
            return None, -1

        # 读取JSON文件
        print(f"正在读取文件：{file_path}")
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)

        # 检查数据结构
        if not isinstance(data, dict):
            print("错误：JSON文件的根结构不是对象类型")
            return None, -1

        # 提取所有Band值
        band_values = []
        object_count = 0

        for key, value in data.items():
            if isinstance(value, dict) and 'Band' in value:
                band_data = value['Band']
                if isinstance(band_data, list) and len(band_data) == 2:
                    band_values.append(band_data)  # 添加为子列表，保持2列结构
                    object_count += 1
                else:
                    print(f"警告：对象 '{key}' 的Band值不是有效的2元素数组")
            else:
                print(f"警告：对象 '{key}' 没有 'Band' 键或结构不正确")

        # 转换为numpy数组
        if band_values:
            band_array = np.array(band_values, dtype=np.int32)
            return band_array, object_count
        else:
            return np.array([], dtype=np.int32).reshape(0, 2), object_count

    except json.JSONDecodeError as e:
        print(f"JSON解析错误：{e}")
        return None, -1
    except Exception as e:
        print(f"读取文件时发生错误：{e}")
        return None, -1

def filter_points_by_distance(points, threshold=50):
    """
    根据距离阈值过滤点集，使用贪婪算法

    Args:
        points (np.ndarray): 形状为(n, 2)的numpy数组
        threshold (float): 距离阈值

    Returns:
        tuple: (filtered_points, indices) 过滤后的点和在原数组中的索引
    """
    if len(points) == 0:
        return np.array([]).reshape(0, 2), np.array([], dtype=int)

    n_points = len(points)
    remaining_indices = list(range(n_points))
    filtered_indices = []

    while remaining_indices:
        # 选择第一个剩余点作为基准点
        current_idx = remaining_indices[0]
        current_point = points[current_idx]
        filtered_indices.append(current_idx)

        # 找到所有与当前点距离小于阈值的点（除了当前点本身）
        points_to_remove = []
        for i in remaining_indices[1:]:  # 从下一个点开始检查
            distance = np.linalg.norm(points[i] - current_point)
            if distance < threshold:
                points_to_remove.append(i)

        # 从剩余列表中移除这些点
        for idx in reversed(points_to_remove):  # 逆序删除避免索引错位
            remaining_indices.remove(idx)

        # 移除当前点
        remaining_indices.pop(0)

    # 根据过滤后的索引提取点
    filtered_points = points[filtered_indices]

    return filtered_points, np.array(filtered_indices, dtype=int)

def plot_points(original_points, filtered_points, title_prefix=""):
    """
    绘制原始点和过滤后的点的对比图

    Args:
        original_points (np.ndarray): 原始点数组
        filtered_points (np.ndarray): 过滤后的点数组
        title_prefix (str): 图表标题前缀
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

    # 绘制原始点
    if len(original_points) > 0:
        ax1.scatter(original_points[:, 0], original_points[:, 1],
                   c='blue', alpha=0.6, s=30, edgecolors='black')
        ax1.set_title(f'{title_prefix}Original Points\nTotal: {len(original_points)} points')
        ax1.set_xlabel('X Coordinate')
        ax1.set_ylabel('Y Coordinate')
        ax1.grid(True, alpha=0.3)

    # 绘制过滤后的点
    if len(filtered_points) > 0:
        ax2.scatter(filtered_points[:, 0], filtered_points[:, 1],
                   c='red', alpha=0.8, s=50, edgecolors='black', marker='^')
        ax2.set_title(f'{title_prefix}Filtered Points\nTotal: {len(filtered_points)} points')
        ax2.set_xlabel('X Coordinate')
        ax2.set_ylabel('Y Coordinate')
        ax2.grid(True, alpha=0.3)

        # 设置相同的坐标范围
        x_min = min(original_points[:, 0].min(), filtered_points[:, 0].min())
        x_max = max(original_points[:, 0].max(), filtered_points[:, 0].max())
        y_min = min(original_points[:, 1].min(), filtered_points[:, 1].min())
        y_max = max(original_points[:, 1].max(), filtered_points[:, 1].max())

        ax1.set_xlim(x_min - 100, x_max + 100)
        ax1.set_ylim(y_min - 100, y_max + 100)
        ax2.set_xlim(x_min - 100, x_max + 100)
        ax2.set_ylim(y_min - 100, y_max + 100)

    plt.tight_layout()
    try:
        plt.show()
    except:
        print("注意：当前环境不支持图形显示")
        plt.close('all')

def save_filtered_indices_to_json(indices, filename):
    """
    将过滤后的索引数组保存为JSON文件

    Args:
        indices (np.ndarray): 过滤后的索引数组
        filename (str): 保存的文件名
    """
    if len(indices) == 0:
        print("警告：没有索引数据可以保存")
        return

    try:
        # 准备保存的数据结构
        data_to_save = {
            "filtered_indices": indices.tolist(),
            "count": len(indices),
            "description": "Distance-filtered indices from band data"
        }

        # 保存为JSON文件
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data_to_save, f, indent=2, ensure_ascii=False)

        print(f"✓ 过滤后的索引数组已保存为: {filename}")
        print(f"  - 索引数量: {len(indices)}")
        print(f"  - 文件大小: {os.path.getsize(filename)} 字节")

    except Exception as e:
        print(f"保存索引数组时出错：{e}")

def load_filtered_indices(filename):
    """
    从JSON文件中加载过滤后的索引数组

    Args:
        filename (str): JSON文件名

    Returns:
        np.ndarray: 过滤后的索引数组，如果出错则返回None
    """
    try:
        if not os.path.exists(filename):
            print(f"错误：文件 '{filename}' 不存在")
            return None

        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)

        indices = np.array(data['filtered_indices'], dtype=int)
        print(f"✓ 成功加载过滤索引：{len(indices)} 个索引")
        return indices

    except Exception as e:
        print(f"加载索引文件时出错：{e}")
        return None

def filter_json_by_indices(input_file, indices, output_file):
    """
    根据索引数组过滤JSON文件中的对象

    Args:
        input_file (str): 输入JSON文件路径
        indices (np.ndarray): 过滤索引数组
        output_file (str): 输出JSON文件路径

    Returns:
        bool: 是否成功
    """
    try:
        # 读取原始JSON文件
        print(f"正在读取文件：{input_file}")
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        if not isinstance(data, dict):
            print(f"错误：{input_file} 的根结构不是对象类型")
            return False

        # 将字典的键转换为列表以便按索引访问
        keys = list(data.keys())
        filtered_data = {}

        # 根据索引提取对应的对象
        for idx in indices:
            if 0 <= idx < len(keys):
                key = keys[idx]
                filtered_data[key] = data[key]
            else:
                print(f"警告：索引 {idx} 超出范围，跳过")

        # 保存过滤后的数据
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(filtered_data, f, indent=2, ensure_ascii=False)

        print(f"✓ 过滤完成：{input_file}")
        print(f"  - 原始对象数量：{len(data)}")
        print(f"  - 过滤后对象数量：{len(filtered_data)}")
        print(f"  - 保存到：{output_file}")

        return True

    except Exception as e:
        print(f"过滤文件 {input_file} 时出错：{e}")
        return False

def process_all_files_with_indices(rata_name):
    """
    使用过滤索引处理所有4个JSON文件

    Args:
        rata_name (str): rata标识符，如"0_3"
    """
    # 定义文件映射
    file_mappings = [
        (f"filter_rata_{rata_name}/TI_data_com_flot", f"filter_rata_{rata_name}/filter_data_com_flot"),
        (f"filter_rata_{rata_name}/TI_data_com_str", f"filter_rata_{rata_name}/filter_data_com_str"),
        (f"filter_rata_{rata_name}/TI_data_sim_flot", f"filter_rata_{rata_name}/filter_data_sim_flot"),
        (f"filter_rata_{rata_name}/TI_data_sim_str", f"filter_rata_{rata_name}/filter_data_sim_str")
    ]

    # 加载过滤索引
    indices_file = f"filter_rata_{rata_name}/filtered_indices_{rata_name}.json"
    indices = load_filtered_indices(indices_file)

    if indices is None:
        print("无法加载过滤索引，退出处理")
        return

    print(f"\n开始使用过滤索引处理所有文件...")
    print("=" * 60)

    success_count = 0
    for input_prefix, output_prefix in file_mappings:
        input_file = f"{input_prefix}_{rata_name}.json"
        output_file = f"{output_prefix}_{rata_name}.json"

        if os.path.exists(input_file):
            if filter_json_by_indices(input_file, indices, output_file):
                success_count += 1
        else:
            print(f"警告：输入文件不存在 - {input_file}")

    print("\n" + "=" * 60)
    print(f"处理完成：成功处理 {success_count}/{len(file_mappings)} 个文件")

def main():
    rata_name = "0_8"
    # 指定JSON文件路径
    json_file_path = f"filter_rata_{rata_name}/TI_data_sim_flot_{rata_name}.json"
    # 提取Band值并存储到numpy数组
    band_array, object_count = extract_band_values(json_file_path)

    if band_array is not None and object_count > 0:
        print(f"\n提取结果：")
        print(f"- JSON文件 '{json_file_path}' 中包含 {object_count} 个对象")
        print(f"- Band数组形状：{band_array.shape} (n行2列)")
        print(f"- Band数组数据类型：{band_array.dtype}")
        print(f"- Band值范围：{band_array.min()} - {band_array.max()}")

        # 显示前5个Band值作为示例
        if len(band_array) > 0:
            print(f"- 前5个Band值示例：")
            for i in range(min(5, len(band_array))):
                print(f"  对象{i+1}: {band_array[i]}")

        # 进行距离过滤
        print(f"\n开始距离过滤（阈值：50）...")
        filtered_array, filtered_indices = filter_points_by_distance(band_array, threshold=3)

        print(f"\n过滤结果：")
        print(f"- 原始点数量：{len(band_array)}")
        print(f"- 过滤后点数量：{len(filtered_array)}")
        print(f"- 保留比例：{len(filtered_array)/len(band_array)*100:.1f}%")

        if len(filtered_indices) > 0:
            print(f"- 保留点的原索引：{filtered_indices[:10].tolist()}" +
                  (f"...等{len(filtered_indices)-10}个" if len(filtered_indices) > 10 else ""))

        # 保存过滤后的索引数组
        save_filtered_indices_to_json(filtered_indices, f"filter_rata_{rata_name}/filtered_indices_{rata_name}.json")

        # 绘制对比图
        print(f"\n正在生成可视化图表...")
        plot_points(band_array, filtered_array, "Band数据")

        # 处理所有文件
        process_all_files_with_indices(rata_name)

    else:
        print("\n提取失败，请检查文件路径和格式")

if __name__ == "__main__":
    main()
