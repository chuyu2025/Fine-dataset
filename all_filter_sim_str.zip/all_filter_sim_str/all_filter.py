import json
import os
import glob

def merge_json_files(directory_path, output_filename="all-filter-sim-flot.json"):
    """
    将指定目录下的filter_data_sim_str_*.json文件合并为一个JSON文件，并重新编号对象

    Args:
        directory_path (str): 包含filter_rata_*子目录的根目录路径
        output_filename (str): 输出文件名

    Returns:
        bool: 是否成功
    """
    # 定义需要处理的目录
    target_dirs = [
        "filter_rata_0_3",
        "filter_rata_0_4",
        "filter_rata_0_5",
        "filter_rata_0_6",
        "filter_rata_0_7",
        "filter_rata_0_8",
        "filter_rata_1_0",
        "filter_rata_1_5",
        "filter_rata_2_2"
    ]

    # 找到所有目标JSON文件
    json_files = []
    for target_dir in target_dirs:
        target_path = os.path.join(directory_path, target_dir)
        if os.path.exists(target_path):
            # 在每个目录中查找filter_data_sim_str_*.json文件
            pattern = os.path.join(target_path, "filter_data_sim_str_*.json")
            found_files = glob.glob(pattern)
            json_files.extend(found_files)

    # 过滤掉输出文件（以防万一）
    json_files = [f for f in json_files if not os.path.basename(f).startswith(('all-filter', 'all_filter'))]

    if not json_files:
        print(f"在目录 {directory_path} 中没有找到可合并的JSON文件")
        return False

    print(f"找到 {len(json_files)} 个JSON文件待合并:")
    for f in sorted(json_files):
        print(f"  - {os.path.basename(f)}")

    # 合并所有数据
    merged_data = {}
    total_objects = 0
    object_counter = 1  # 从1开始编号

    for json_file in sorted(json_files):  # 按文件名排序处理，保证一致性
        try:
            print(f"\n正在处理文件：{os.path.basename(json_file)}")

            # 读取JSON文件
            with open(json_file, 'r', encoding='utf-8') as f:
                file_data = json.load(f)

            if not isinstance(file_data, dict):
                print(f"警告：{json_file} 的根结构不是对象类型，跳过")
                continue

            # 统计该文件中的对象数量
            file_objects = len(file_data)
            print(f"  - 包含 {file_objects} 个对象")

            # 将该文件的数据添加到合并数据中，并重新编号
            for key, value in file_data.items():
                new_key = f"data_{object_counter}"
                merged_data[new_key] = value
                object_counter += 1

            total_objects += file_objects

        except Exception as e:
            print(f"处理文件 {json_file} 时出错：{e}")
            continue

    # 保存合并后的数据
    # 获取脚本所在目录，将输出文件保存在对应文件夹中
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(script_dir, output_filename)

    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(merged_data, f, indent=2, ensure_ascii=False)

        print(f"\n✓ 合并完成！")
        print(f"- 处理文件数：{len(json_files)}")
        print(f"- 总对象数：{total_objects}")
        print(f"- 保存路径：{output_path}")
        print(f"- 文件大小：{os.path.getsize(output_path)} 字节")

        # 验证合并结果
        with open(output_path, 'r', encoding='utf-8') as f:
            verification_data = json.load(f)

        verification_count = len(verification_data)
        print(f"- 验证对象数：{verification_count}")

        if verification_count == total_objects:
            print("✓ 数据完整性验证通过！")
        else:
            print("⚠ 数据完整性验证失败！")

        return True

    except Exception as e:
        print(f"保存合并文件时出错：{e}")
        return False

def main():
    # 获取父目录（data_filtering目录）
    current_directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    print("开始合并filter_data_sim_str_*.json文件...")
    print("将从以下目录中查找并合并文件：")
    dirs = ["filter_rata_0_3", "filter_rata_0_4", "filter_rata_0_5", "filter_rata_0_6",
            "filter_rata_0_7", "filter_rata_0_8", "filter_rata_1_0", "filter_rata_1_5", "filter_rata_2_2"]
    for d in dirs:
        print(f"  - {d}")
    print("=" * 60)

    # 合并所有filter_data_sim_str_*.json文件
    success = merge_json_files(current_directory, "all-filter-sim-str.json")

    if success:
        print("\n" + "=" * 60)
        print("合并任务完成！")
        print("生成的文件：all-filter-sim-str.json")
        print("该文件包含了所有filter_data_sim_str_*.json文件的整合版本，对象按顺序重新编号。")
    else:
        print("合并任务失败，请检查错误信息。")

if __name__ == "__main__":
    main()